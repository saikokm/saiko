# telegram-yt_mp3-bot
This OpenSource bot will let you to download every YouTube video in MP3 format. Available in Spanish and English

You can use it in Telegram by typing @dwnmp3Bot or here: https://goo.gl/12AADY
